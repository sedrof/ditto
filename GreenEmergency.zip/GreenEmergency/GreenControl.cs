namespace GreenGreen
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.IO;
    using System.Windows.Forms;

    public class GreenControl : Form
    {
        private IContainer components = null;
        private Jigglypuff jigglypuff = new Jigglypuff();
        private Button loadButton;
        private Button newDittoButton;
        private OpenFileDialog openFileDialog1;
        private Button saveButton;
        private SaveFileDialog saveFileDialog1;
        private WebBrowser webBrowser1;
        private Button xyBtn;
        private TextBox xyColor;
        private TextBox xyDisplay;
        private Label label1;
        private Timer xyTimer;

        public GreenControl()
        {
            this.InitializeComponent();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void GreenControl_Load(object sender, EventArgs e)
        {
            this.xyDisplay.Enabled = false;
            this.xyColor.Enabled = false;
        }

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.webBrowser1 = new System.Windows.Forms.WebBrowser();
            this.newDittoButton = new System.Windows.Forms.Button();
            this.loadButton = new System.Windows.Forms.Button();
            this.saveButton = new System.Windows.Forms.Button();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.xyBtn = new System.Windows.Forms.Button();
            this.xyDisplay = new System.Windows.Forms.TextBox();
            this.xyTimer = new System.Windows.Forms.Timer(this.components);
            this.xyColor = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // webBrowser1
            // 
            this.webBrowser1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.webBrowser1.Location = new System.Drawing.Point(0, 0);
            this.webBrowser1.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowser1.Name = "webBrowser1";
            this.webBrowser1.Size = new System.Drawing.Size(204, 168);
            this.webBrowser1.TabIndex = 0;
            // 
            // newDittoButton
            // 
            this.newDittoButton.Location = new System.Drawing.Point(8, 8);
            this.newDittoButton.Name = "newDittoButton";
            this.newDittoButton.Size = new System.Drawing.Size(184, 62);
            this.newDittoButton.TabIndex = 1;
            this.newDittoButton.Text = "New Emergency";
            this.newDittoButton.UseVisualStyleBackColor = true;
            this.newDittoButton.Click += new System.EventHandler(this.newDittoButton_Click);
            // 
            // loadButton
            // 
            this.loadButton.Location = new System.Drawing.Point(8, 77);
            this.loadButton.Name = "loadButton";
            this.loadButton.Size = new System.Drawing.Size(91, 23);
            this.loadButton.TabIndex = 2;
            this.loadButton.Text = "Load Emergency";
            this.loadButton.UseVisualStyleBackColor = true;
            this.loadButton.Click += new System.EventHandler(this.loadButton_Click);
            // 
            // saveButton
            // 
            this.saveButton.Location = new System.Drawing.Point(105, 77);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(87, 23);
            this.saveButton.TabIndex = 3;
            this.saveButton.Text = "Save Ditto";
            this.saveButton.UseVisualStyleBackColor = true;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // saveFileDialog1
            // 
            this.saveFileDialog1.FileOk += new System.ComponentModel.CancelEventHandler(this.saveFileDialog1_FileOk_1);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.FileOk += new System.ComponentModel.CancelEventHandler(this.openFileDialog1_FileOk);
            // 
            // xyBtn
            // 
            this.xyBtn.Location = new System.Drawing.Point(147, 106);
            this.xyBtn.Name = "xyBtn";
            this.xyBtn.Size = new System.Drawing.Size(45, 23);
            this.xyBtn.TabIndex = 4;
            this.xyBtn.Text = "Cursor";
            this.xyBtn.UseVisualStyleBackColor = true;
            this.xyBtn.Click += new System.EventHandler(this.xyBtn_Click);
            // 
            // xyDisplay
            // 
            this.xyDisplay.Location = new System.Drawing.Point(8, 108);
            this.xyDisplay.Name = "xyDisplay";
            this.xyDisplay.Size = new System.Drawing.Size(117, 20);
            this.xyDisplay.TabIndex = 5;
            this.xyDisplay.TextChanged += new System.EventHandler(this.xyDisplay_TextChanged);
            // 
            // xyTimer
            // 
            this.xyTimer.Interval = 50;
            this.xyTimer.Tick += new System.EventHandler(this.xyTimer_Tick);
            // 
            // xyColor
            // 
            this.xyColor.Location = new System.Drawing.Point(131, 108);
            this.xyColor.Name = "xyColor";
            this.xyColor.Size = new System.Drawing.Size(10, 20);
            this.xyColor.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 144);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(158, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "This copy of Ditto is belongs to seller :)";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // GreenControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(204, 168);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.xyColor);
            this.Controls.Add(this.xyDisplay);
            this.Controls.Add(this.xyBtn);
            this.Controls.Add(this.saveButton);
            this.Controls.Add(this.loadButton);
            this.Controls.Add(this.newDittoButton);
            this.Controls.Add(this.webBrowser1);
            this.Name = "GreenControl";
            this.Text = "GreenGreen";
            this.Load += new System.EventHandler(this.GreenControl_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void loadButton_Click(object sender, EventArgs e)
        {
            if (this.openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                string fileName = this.openFileDialog1.FileName;
                try
                {
                    string str2 = File.ReadAllText(fileName);
                    string[] separator = new string[] { Environment.NewLine + Environment.NewLine };
                    int num = 0;
                    foreach (string str3 in str2.Split(separator, (StringSplitOptions)num))
                    {
                        Program.newDitto().SetInstructions(str3);
                    }
                }
                catch (IOException)
                {
                }
            }
        }

        private void newDittoButton_Click(object sender, EventArgs e)
        {
            Program.newDitto();
        }

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            this.saveFileDialog1.DefaultExt = "GreenGreen";
            int num = (int)this.saveFileDialog1.ShowDialog();
        }

        private void saveFileDialog1_FileOk_1(object sender, CancelEventArgs e)
        {
            string fileName = this.saveFileDialog1.FileName;
            string str2 = "";
            foreach (GreenForm form in Program.dittos)
            {
                str2 = str2 + form.GetInstructions();
                str2 = str2 + Environment.NewLine + Environment.NewLine;
            }
            File.WriteAllText(fileName, str2.TrimEnd(new char[] { '\r', '\n', ' ' }));
        }

        private void xyBtn_Click(object sender, EventArgs e)
        {
            if (this.xyTimer.Enabled)
            {
                this.xyDisplay.Text = "";
                this.xyColor.BackColor = Color.White;
            }
            this.xyTimer.Enabled = !this.xyTimer.Enabled;
            this.xyDisplay.Enabled = !this.xyDisplay.Enabled;
            this.xyColor.Enabled = !this.xyDisplay.Enabled;
        }

        private void xyDisplay_TextChanged(object sender, EventArgs e)
        {
        }

        private void xyTimer_Tick(object sender, EventArgs e)
        {
            Color colorFromScreen = this.jigglypuff.GetColorFromScreen(Cursor.Position);
            this.xyColor.BackColor = colorFromScreen;
            this.xyDisplay.Text = Cursor.Position.X.ToString() + " " + Cursor.Position.Y.ToString() + " " + colorFromScreen.R.ToString() + "." + colorFromScreen.G.ToString() + "." + colorFromScreen.B.ToString();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}