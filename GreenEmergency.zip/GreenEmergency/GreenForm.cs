namespace GreenGreen
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Drawing;
    using System.Runtime.InteropServices;
    using System.Threading;
    using System.Windows.Forms;

    public class GreenForm : Form
    {
        private IContainer components = null;
        private Button f8button;
        private Gastly gastly = new Gastly();
        private TextBox handlerBox;
        private int index;
        private string instructions = "";
        private RichTextBox instructionsDisplay;
        private TextBox instructionsField;
        private Jigglypuff jigglypuff = new Jigglypuff();
        private Point point = new Point();
        private bool running = false;
        private Button startButton;
        private Thread worker;

        public GreenForm()
        {
            this.InitializeComponent();
            this.worker = new Thread(new ThreadStart(this.PerformMacro));
            this.worker.IsBackground = true;
            this.worker.Start();
            this.index = Program.dittos.Count;
            this.Text = "Ditto - " + this.index;
            this.instructionsDisplay.Hide();
            this.instructionsDisplay.Enabled = false;
        }

        private void Debug(string text)
        {
            this.startButton.Invoke((Action)(() => this.startButton.Text = text));
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void f8button_Click(object sender, EventArgs e)
        {
            RegisterHotKey(base.Handle, 1, 0, 0x77);
            this.f8button.Enabled = false;
        }

        [DllImport("user32.dll", EntryPoint = "FindWindow", SetLastError = true)]
        private static extern IntPtr FindWindowByCaption(IntPtr ZeroOnly, string lpWindowName);
        private IntPtr GetActiveWindow() =>
            GetForegroundWindow();

        [DllImport("user32.dll")]
        private static extern IntPtr GetForegroundWindow();
        private void getHwnd()
        {
            string str = "false";
            IntPtr activeWindow = this.GetActiveWindow();
            this.point = Cursor.Position;
            UnregisterHotKey(base.Handle, 1);
            try
            {
                this.handlerBox.Text = "Loading Handler...";
                str = "o_O cracked :)";
            }
            catch (Exception)
            {
                str = "false";
            }
            finally
            {
                if (str != "false")
                {
                    this.handlerBox.Text = "h: " + activeWindow.ToString() + " x:" + this.point.X.ToString() + " y:" + this.point.Y.ToString();
                    this.gastly.setWindow(activeWindow);
                    this.jigglypuff.setWindow(activeWindow);
                }
                else
                {
                    this.handlerBox.Text = "You don't have enough badges";
                }
                this.f8button.Enabled = true;
            }
        }

        public string GetInstructions() =>
            this.instructionsField.Text;

        private void InitializeComponent()
        {
            this.startButton = new System.Windows.Forms.Button();
            this.instructionsField = new System.Windows.Forms.TextBox();
            this.handlerBox = new System.Windows.Forms.TextBox();
            this.f8button = new System.Windows.Forms.Button();
            this.instructionsDisplay = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // startButton
            // 
            this.startButton.Location = new System.Drawing.Point(12, 12);
            this.startButton.Name = "startButton";
            this.startButton.Size = new System.Drawing.Size(187, 75);
            this.startButton.TabIndex = 0;
            this.startButton.Text = "Start";
            this.startButton.UseVisualStyleBackColor = true;
            this.startButton.Click += new System.EventHandler(this.startButton_Click);
            // 
            // instructionsField
            // 
            this.instructionsField.Location = new System.Drawing.Point(13, 94);
            this.instructionsField.Multiline = true;
            this.instructionsField.Name = "instructionsField";
            this.instructionsField.Size = new System.Drawing.Size(186, 95);
            this.instructionsField.TabIndex = 1;
            this.instructionsField.TextChanged += new System.EventHandler(this.instructionsField_TextChanged);
            // 
            // handlerBox
            // 
            this.handlerBox.Location = new System.Drawing.Point(13, 196);
            this.handlerBox.Name = "handlerBox";
            this.handlerBox.Size = new System.Drawing.Size(140, 20);
            this.handlerBox.TabIndex = 2;
            // 
            // f8button
            // 
            this.f8button.Location = new System.Drawing.Point(160, 195);
            this.f8button.Name = "f8button";
            this.f8button.Size = new System.Drawing.Size(40, 23);
            this.f8button.TabIndex = 3;
            this.f8button.Text = "F8";
            this.f8button.UseVisualStyleBackColor = true;
            this.f8button.Click += new System.EventHandler(this.f8button_Click);
            // 
            // instructionsDisplay
            // 
            this.instructionsDisplay.Location = new System.Drawing.Point(13, 93);
            this.instructionsDisplay.Name = "instructionsDisplay";
            this.instructionsDisplay.Size = new System.Drawing.Size(186, 95);
            this.instructionsDisplay.TabIndex = 4;
            this.instructionsDisplay.Text = "";
            this.instructionsDisplay.TextChanged += new System.EventHandler(this.instructionsDisplay_TextChanged);
            // 
            // GreenForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(212, 226);
            this.Controls.Add(this.instructionsDisplay);
            this.Controls.Add(this.f8button);
            this.Controls.Add(this.handlerBox);
            this.Controls.Add(this.instructionsField);
            this.Controls.Add(this.startButton);
            this.Name = "GreenForm";
            this.Text = "Ditto";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void instructionsDisplay_TextChanged(object sender, EventArgs e)
        {
        }

        private void instructionsField_TextChanged(object sender, EventArgs e)
        {
            this.instructions = this.instructionsField.Text.ToString();
        }

        private void Mock()
        {
            this.Debug("LOOOL");
        }

        private void newBtn_Click(object sender, EventArgs e)
        {
            Program.newDitto();
        }

        private void Pause()
        {
            this.startButton.Text = "Start";
            this.running = false;
            this.instructionsField.Show();
            this.instructionsDisplay.Hide();
        }

        private void PerformMacro()
        {
            while (true)
            {
                if (this.running)
                {
                    Action method = null;
                    this.instructions = this.GetInstructions();
                    string[] lines = this.instructions.Trim().Split(new char[] { '\n' });
                    int linecount = 0;
                    foreach (string str in lines)
                    {
                        linecount++;
                        if (method == null)
                        {
                            method = delegate {
                                this.instructionsDisplay.Clear();
                                int num = 0;
                                foreach (string tekstas in lines)
                                {
                                    num++;
                                    if (num == linecount)
                                    {
                                        int start = this.instructionsDisplay.TextLength;
                                        this.instructionsDisplay.AppendText(tekstas);
                                        int textLength = this.instructionsDisplay.TextLength;
                                        this.instructionsDisplay.Select(start, textLength);
                                        this.instructionsDisplay.SelectionColor = Color.Blue;
                                        this.instructionsDisplay.ScrollToCaret();
                                        this.instructionsDisplay.Select(0, 0);
                                    }
                                    else
                                    {
                                        this.instructionsDisplay.AppendText(tekstas);
                                    }
                                }
                            };
                        }
                        this.instructionsDisplay.BeginInvoke(method);
                        if (this.running)
                        {
                            string[] strArray = str.Trim().Split(new char[] { ' ' });
                            if (strArray[0] == "keypress")
                            {
                                this.gastly.KeyPress(strArray[1]);
                            }
                            if (strArray[0] == "rightclick")
                            {
                                if (strArray.Length == 1)
                                {
                                    this.gastly.RightClick(this.point);
                                }
                                else
                                {
                                    this.gastly.RightClick(new Point(int.Parse(strArray[1]), int.Parse(strArray[2])));
                                }
                            }
                            if (strArray[0] == "leftclick")
                            {
                                if (strArray.Length == 1)
                                {
                                    this.gastly.LeftClick(this.point);
                                }
                                else
                                {
                                    this.gastly.LeftClick(new Point(int.Parse(strArray[1]), int.Parse(strArray[2])));
                                }
                            }
                            if (strArray[0] == "startditto")
                            {
                                GreenForm ditto = Program.dittos[int.Parse(strArray[1])];
                                ditto.BeginInvoke((Action)(() => ditto.Play()));
                            }
                            if (strArray[0] == "stopditto")
                            {
                                GreenForm ditto = Program.dittos[int.Parse(strArray[1])];
                                ditto.BeginInvoke((Action)(() => ditto.Pause()));
                            }
                            if (strArray[0] == "wait")
                            {
                                int num = 0;
                                if (strArray.Length > 2)
                                {
                                    int x = int.Parse(strArray[1]);
                                    int y = int.Parse(strArray[2]);
                                    if (strArray.Length == 5)
                                    {
                                        num = this.timeString(strArray[4]);
                                    }
                                    bool flag = true;
                                    while (flag)
                                    {
                                        flag = this.jigglypuff.ExpectColor(new Point(x, y), strArray[3]);
                                        Thread.Sleep(100);
                                        if (strArray.Length == 5)
                                        {
                                            num -= 100;
                                            if (num <= 0)
                                            {
                                                flag = false;
                                            }
                                        }
                                    }
                                }
                                else
                                {
                                    int num4 = this.timeString(strArray[1]) / 100;
                                    for (int i = 0; (i < num4) && this.running; i++)
                                    {
                                        this.gastly.Wait(100);
                                    }
                                }
                            }
                            if (strArray[0] == "closeclient")
                            {
                                this.gastly.Kill();
                            }
                            Thread.Sleep(100);
                        }
                    }
                }
                else
                {
                    this.gastly.Wait(100);
                }
            }
        }

        private void Play()
        {
            string[] strArray = this.instructionsField.Text.Trim().Split(new char[] { '\n' });
            List<string> list = new List<string>();
            foreach (string str in strArray)
            {
                if (str.Contains("#"))
                {
                    this.Text = this.Text.Replace("Ditto", str.Replace("#", ""));
                }
                else
                {
                    list.Add(str);
                }
            }
            this.instructionsField.Text = string.Join('\n'.ToString(), list.ToArray());
            this.startButton.Text = "Stop";
            this.running = true;
            this.instructionsField.Hide();
            this.instructionsDisplay.Show();
        }

        private void PlayPause()
        {
            if (this.running)
            {
                this.Pause();
            }
            else
            {
                this.Play();
            }
        }

        [DllImport("user32.dll")]
        public static extern bool RegisterHotKey(IntPtr hWnd, int id, int fsModifiers, int vlc);
        [DllImport("user32.dll")]
        private static extern bool SetForegroundWindow(IntPtr hWnd);
        private void setGastly()
        {
        }

        public void SetInstructions(string instruction)
        {
            this.instructionsField.Text = instruction;
        }

        private void startButton_Click(object sender, EventArgs e)
        {
            this.PlayPause();
        }

        private int timeString(string masked)
        {
            if (masked.Contains("y"))
            {
                masked = masked.Replace("y", "");
                return (int.Parse(masked));
            }
            if (masked.Contains("s"))
            {
                masked = masked.Replace("s", "");
                return (int.Parse(masked) * 0x3e8);
            }
            if (masked.Contains("m"))
            {
                masked = masked.Replace("m", "");
                return (int.Parse(masked) * 0xea60);
            }
            return int.Parse(masked);
        }

        [DllImport("user32.dll")]
        public static extern bool UnregisterHotKey(IntPtr hWnd, int id);
        protected override void WndProc(ref Message m)
        {
            if ((m.Msg == 0x312) && (m.WParam.ToInt32() == 1))
            {
                this.getHwnd();
            }
            base.WndProc(ref m);
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}