using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Management;

namespace GreenGreen
{


    internal static class Program
    {
        public static List<GreenForm> dittos = new List<GreenForm>();

        public static string Magnemite()
        {
            string str = string.Empty;
            using (ManagementObjectCollection.ManagementObjectEnumerator enumerator = new ManagementClass("win32_processor").GetInstances().GetEnumerator())
            {
                if (enumerator.MoveNext())
                {
                    str = enumerator.Current.Properties["processorID"].Value.ToString();
                }
            }
            string str2 = string.Concat(new object[] { str, Environment.ProcessorCount, "/", Environment.MachineName, "/", Environment.UserDomainName, "/", Environment.UserName, Environment.GetLogicalDrives().Length });
            str2.ToCharArray();
            string str3 = "";
            foreach (char ch in str2)
            {
                str3 = (ch != '/') ? (str3 + ((int)(char.ToUpper(ch) - '@')).ToString()) : (str3 + "/");
            }
            return str3.Replace("-", "").Replace("/", "-");
        }

        [STAThread]
        private static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            string str = "false";
            try
            {
                str = "o_O cracked :)";
            }
            finally
            {
                if (str != "false")
                {
                    GreenControl mainForm = new GreenControl
                    {
                        Text = "GreenGreen (" + str + ")"
                    };
                    Application.Run(mainForm);
                }
            }
        }

        public static GreenForm newDitto()
        {
            GreenForm item = new GreenForm();
            dittos.Add(item);
            item.Show();
            return item;
        }

        private static void newThread()
        {
            GreenForm item = new GreenForm();
            dittos.Add(item);
            Application.Run(item);
        }
    }
}
